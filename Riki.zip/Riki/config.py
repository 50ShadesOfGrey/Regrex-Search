# encoding: utf-8

SECRET_KEY='a unique and long key'
TITLE='Riki' 
HISTORY_SHOW_MAX=30
PIC_BASE = '/static/content/'
CONTENT_DIR = 'C:/Users/smitp/Riki/content'
USER_DIR = 'C:/Users/smitp/Riki/user'
NUMBER_OF_HISTORY = 5
PRIVATE = True
