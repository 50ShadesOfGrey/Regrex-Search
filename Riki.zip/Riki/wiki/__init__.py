from wiki.core import Wiki
from wiki.web import create_app

__all__ = ['Wiki', 'create_app']
